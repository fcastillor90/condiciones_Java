function example(a, b, c) {
    return a + b + c;
}

example();

suma();

suma = function (a, b, c) {
    return a +b +c;
}